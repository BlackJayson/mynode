This is a stub types definition for @types/keyv (https://github.com/jaredwray/keyv).

keyv provides its own type definitions, so you don't need @types/keyv installed!