## [3.0.2](https://github.com/thenativeweb/boolean/compare/3.0.1...3.0.2) (2020-11-03)


### Bug Fixes

* Fix headline for robot section in readme. ([#191](https://github.com/thenativeweb/boolean/issues/191)) ([6b7b72b](https://github.com/thenativeweb/boolean/commit/6b7b72b6d5d5c1ad2251c5959b35c8c87b3421a5))

## [3.0.1](https://github.com/thenativeweb/boolean/compare/3.0.0...3.0.1) (2020-02-11)


### Bug Fixes

* Simplify comparison code to not use unicode regexp flag ([#99](https://github.com/thenativeweb/boolean/issues/99)) ([2be2aeb](https://github.com/thenativeweb/boolean/commit/2be2aeb244c060eccb388dacc6903bbad193e745))
