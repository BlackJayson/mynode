var parent = require('../../es/array/of');

module.exports = parent;
