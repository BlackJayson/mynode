var parent = require('../../es/array/flat');

module.exports = parent;
