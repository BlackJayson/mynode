var parent = require('../../es/array/find-index');

module.exports = parent;
