var parent = require('../../../es/array/virtual/entries');

module.exports = parent;
