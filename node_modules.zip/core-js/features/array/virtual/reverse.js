var parent = require('../../../es/array/virtual/reverse');

module.exports = parent;
