var parent = require('../../../es/array/virtual/reduce-right');

module.exports = parent;
