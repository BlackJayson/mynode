require('../../../modules/es.map');
require('../../../modules/esnext.array.unique-by');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').uniqueBy;
