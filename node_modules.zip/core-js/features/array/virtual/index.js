var parent = require('../../../es/array/virtual');
require('../../../modules/es.map');
require('../../../modules/esnext.array.at');
require('../../../modules/esnext.array.filter-out');
require('../../../modules/esnext.array.find-last');
require('../../../modules/esnext.array.find-last-index');
require('../../../modules/esnext.array.unique-by');

module.exports = parent;
