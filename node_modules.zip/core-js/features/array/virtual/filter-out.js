require('../../../modules/esnext.array.filter-out');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').filterOut;
