var parent = require('../../es/function/has-instance');

module.exports = parent;
