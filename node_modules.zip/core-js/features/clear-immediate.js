var parent = require('../stable/clear-immediate');

module.exports = parent;
